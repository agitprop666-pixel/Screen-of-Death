from __future__ import annotations

import os
import re
import sys
import time
import tempfile
import threading
import subprocess
from pathlib import Path

from PyQt6.QtCore import Qt, QTimer, pyqtSignal, QObject
from PyQt6.QtGui import QColor, QFont, QIcon, QPainter, QPixmap
from PyQt6.QtWidgets import (
    QApplication, QComboBox, QFileDialog, QFrame, QHBoxLayout,
    QLabel, QLineEdit, QMessageBox, QPushButton, QSplashScreen,
    QVBoxLayout, QWidget,
)

import mss

# =============================================================================
# Windows Bootstrap
# =============================================================================

if sys.platform == "win32":
    import ctypes
    CREATE_NO_WINDOW = 0x08000000
    ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
        "DeathsHeadSoftware.ScreenOfDeath"
    )
else:
    CREATE_NO_WINDOW = 0

# =============================================================================
# Constants
# =============================================================================

APP_NAME    = "Screen of Death"
ORG_NAME    = "Death's Head Software"
APP_VERSION = "1.0.0"

# =============================================================================
# Helpers
# =============================================================================

def resource_path(relative: str) -> str:
    base = getattr(sys, "_MEIPASS", os.path.abspath("."))
    return os.path.join(base, relative)


def get_monitors() -> list[tuple[str, dict]]:
    result = []
    with mss.MSS() as sct:
        result.append(("All Monitors", sct.monitors[0]))
        for i, mon in enumerate(sct.monitors[1:], 1):
            w, h = mon["width"], mon["height"]
            result.append((f"Monitor {i}  ({w}x{h})", mon))
    return result


def get_audio_devices() -> list[str]:
    """Enumerate DirectShow audio devices. Returns ['No Audio', ...names...]."""
    devices: list[str] = ["No Audio"]
    try:
        proc = subprocess.run(
            ["ffmpeg", "-list_devices", "true", "-f", "dshow", "-i", "dummy"],
            capture_output=True,
            text=True,
            timeout=10,
            creationflags=CREATE_NO_WINDOW,
        )
        print("[audio enum] raw ffmpeg output:")
        print(proc.stderr)

        for line in proc.stderr.splitlines():
            # ffmpeg 8.x lists all devices flat with inline (audio)/(video) tags.
            # Older builds used section headers — matching on (audio) handles both.
            if "Alternative name" in line:
                continue
            m = re.search(r'"([^"]+)"\s*\(audio\)', line)
            if m:
                name = m.group(1).strip()
                if name and name not in devices:
                    devices.append(name)

        print(f"[audio enum] found: {devices}")
    except Exception as exc:
        print(f"[audio enum] {exc}")
    return devices

# =============================================================================
# Splash
# =============================================================================

def create_splash() -> QSplashScreen | None:
    try:
        splash_path = Path(resource_path("splash.png"))
        if splash_path.exists():
            pixmap = QPixmap(str(splash_path))
            if pixmap.isNull():
                pixmap = QPixmap(800, 600)
                pixmap.fill(QColor(20, 20, 20))
            if pixmap.width() != 800 or pixmap.height() != 600:
                pixmap = pixmap.scaled(
                    800, 600,
                    Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation,
                )
            painter = QPainter(pixmap)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
            r = pixmap.rect(); r.setTop(40); r.setBottom(100)
            painter.drawText(r, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, APP_NAME)
            painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
            fr = pixmap.rect(); fr.setTop(pixmap.height() - 100); fr.setBottom(pixmap.height() - 50)
            painter.drawText(fr, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, ORG_NAME)
            painter.end()
        else:
            pixmap = QPixmap(800, 600)
            pixmap.fill(QColor(20, 20, 20))
            painter = QPainter(pixmap)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
            r = pixmap.rect(); r.setTop(40); r.setBottom(100)
            painter.drawText(r, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, APP_NAME)
            painter.setFont(QFont("Courier", 14))
            skull = [
                "        ___________      ",
                "       /           \\    ",
                "      |  O       O  |   ",
                "      |      ^      |   ",
                "      |   \\_____/   |   ",
                "       \\_         _/    ",
                "         |_______|      ",
            ]
            for i, line in enumerate(skull):
                painter.drawText(250, 250 + i * 25, line)
            painter.setPen(QColor(255, 255, 255))
            painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
            fr = pixmap.rect(); fr.setTop(pixmap.height() - 50); fr.setBottom(pixmap.height())
            painter.drawText(fr, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, ORG_NAME)
            painter.end()
        return QSplashScreen(pixmap, Qt.WindowType.WindowStaysOnTopHint)
    except Exception as exc:
        print(f"Splash error: {exc}")
        return None

# =============================================================================
# Recording Worker
# =============================================================================

class RecordingWorker(QObject):
    finished = pyqtSignal()
    error    = pyqtSignal(str)

    # If the process dies within this many seconds it's a startup failure
    STARTUP_GRACE = 3.0

    def __init__(self, cmd: list[str]) -> None:
        super().__init__()
        self._cmd      = cmd
        self._process: subprocess.Popen | None = None
        self._log_path = os.path.join(tempfile.gettempdir(), "screen_of_death_ffmpeg.log")

    def start(self) -> None:
        threading.Thread(target=self._run, daemon=True).start()

    def _run(self) -> None:
        log_fh = None
        try:
            log_fh = open(self._log_path, "w", encoding="utf-8", errors="replace")
            print("[ffmpeg cmd]", " ".join(self._cmd), flush=True)

            self._process = subprocess.Popen(
                self._cmd,
                stdin=subprocess.PIPE,
                stdout=subprocess.DEVNULL,
                stderr=log_fh,
                creationflags=CREATE_NO_WINDOW,
            )
            t_start = time.monotonic()
            self._process.wait()
            elapsed = time.monotonic() - t_start

            # Died immediately -> startup error
            if elapsed < self.STARTUP_GRACE:
                tail = self._read_log_tail()
                self.error.emit(tail)
                return

        except FileNotFoundError:
            self.error.emit(
                "ffmpeg not found.\nMake sure ffmpeg is on your PATH."
            )
            return
        except Exception as exc:
            self.error.emit(str(exc))
            return
        finally:
            if log_fh:
                log_fh.close()

        self.finished.emit()

    def stop(self) -> None:
        proc = self._process
        if proc and proc.poll() is None:
            # ffmpeg on Windows needs the newline to act on 'q'
            try:
                proc.stdin.write(b"q\n")
                proc.stdin.flush()
            except Exception:
                pass
            # Give ffmpeg time to finalize the MP4 container
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                proc.terminate()
                try:
                    proc.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    proc.kill()

    def _read_log_tail(self, lines: int = 20) -> str:
        try:
            with open(self._log_path, "r", encoding="utf-8", errors="replace") as f:
                all_lines = f.readlines()
            return "".join(all_lines[-lines:]).strip()
        except Exception:
            return "(no log available)"

# =============================================================================
# Stylesheet
# =============================================================================

DARK_STYLE = """
QWidget {
    background-color: #141414;
    color: #e0e0e0;
    font-family: Courier;
    font-size: 12px;
}
QComboBox {
    background-color: #1e1e1e;
    border: 1px solid #444;
    padding: 4px 6px;
    color: #e0e0e0;
}
QComboBox::drop-down { border: none; }
QComboBox QAbstractItemView {
    background-color: #1e1e1e;
    selection-background-color: #8b0000;
    color: #e0e0e0;
    border: 1px solid #555;
}
QLineEdit {
    background-color: #1e1e1e;
    border: 1px solid #444;
    padding: 4px 6px;
    color: #e0e0e0;
}
QPushButton {
    background-color: #1e1e1e;
    border: 1px solid #555;
    padding: 4px 10px;
    color: #e0e0e0;
}
QPushButton:hover {
    background-color: #2a2a2a;
    border-color: #8b0000;
}
QPushButton#record_btn {
    background-color: #8b0000;
    border: 1px solid #cc0000;
    color: #ffffff;
    font-weight: bold;
    font-size: 13px;
    padding: 10px;
    letter-spacing: 1px;
}
QPushButton#record_btn:hover { background-color: #aa0000; }
QPushButton#stop_btn {
    background-color: #3a3a3a;
    border: 1px solid #666;
    color: #cccccc;
    font-weight: bold;
    font-size: 13px;
    padding: 10px;
    letter-spacing: 1px;
}
QPushButton#stop_btn:hover {
    background-color: #4a4a4a;
    border-color: #999;
}
QPushButton#log_btn {
    background-color: #1e1e1e;
    border: 1px solid #333;
    color: #555;
    font-size: 10px;
    padding: 2px 8px;
}
QPushButton#log_btn:hover { color: #ccc; border-color: #666; }
QLabel          { color: #aaaaaa; }
QLabel#title_label  { color: #ffffff; }
QLabel#org_label    { color: #444444; font-size: 10px; }
QLabel#timer_label  { color: #cc0000; font-size: 18px; font-weight: bold; letter-spacing: 2px; }
QLabel#status_label { color: #666666; font-size: 10px; }
QFrame          { color: #2a2a2a; }
"""

# =============================================================================
# Main Window
# =============================================================================

class ScreenOfDeath(QWidget):

    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle(APP_NAME)
        self.resize(420, 360)
        self.setStyleSheet(DARK_STYLE)

        icon_path = resource_path("splash.png")
        if Path(icon_path).exists():
            self.setWindowIcon(QIcon(icon_path))

        self._worker:     RecordingWorker | None = None
        self._elapsed:    int                    = 0
        self._output_dir: str                    = str(Path.home() / "Videos")

        self._tick_timer = QTimer(self)
        self._tick_timer.timeout.connect(self._tick)

        self._monitors      = get_monitors()
        self._audio_devices = get_audio_devices()

        self._build_ui()

    # ------------------------------------------------------------------
    # UI
    # ------------------------------------------------------------------

    def _build_ui(self) -> None:
        root = QVBoxLayout(self)
        root.setSpacing(8)
        root.setContentsMargins(16, 14, 16, 14)

        title = QLabel(APP_NAME)
        title.setObjectName("title_label")
        title.setFont(QFont("Courier", 16, QFont.Weight.Bold))
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        root.addWidget(title)

        org = QLabel(ORG_NAME)
        org.setObjectName("org_label")
        org.setAlignment(Qt.AlignmentFlag.AlignCenter)
        root.addWidget(org)

        root.addWidget(self._sep())

        # Monitor
        row = QHBoxLayout()
        lbl = QLabel("Monitor:"); lbl.setFixedWidth(58)
        row.addWidget(lbl)
        self.monitor_combo = QComboBox()
        for label, _ in self._monitors:
            self.monitor_combo.addItem(label)
        row.addWidget(self.monitor_combo, 1)
        root.addLayout(row)

        # Audio
        row2 = QHBoxLayout()
        lbl2 = QLabel("Audio:"); lbl2.setFixedWidth(58)
        row2.addWidget(lbl2)
        self.audio_combo = QComboBox()
        for dev in self._audio_devices:
            self.audio_combo.addItem(dev)
        row2.addWidget(self.audio_combo, 1)
        root.addLayout(row2)

        root.addWidget(self._sep())

        # Output dir
        dir_row = QHBoxLayout()
        dlbl = QLabel("Dir:"); dlbl.setFixedWidth(58)
        dir_row.addWidget(dlbl)
        self.dir_label = QLabel(self._output_dir)
        self.dir_label.setStyleSheet("color: #c0c0c0; font-size: 11px;")
        dir_row.addWidget(self.dir_label, 1)
        browse_btn = QPushButton("...")
        browse_btn.setFixedWidth(28)
        browse_btn.clicked.connect(self._choose_dir)
        dir_row.addWidget(browse_btn)
        root.addLayout(dir_row)

        # Filename
        fn_row = QHBoxLayout()
        fnlbl = QLabel("File:"); fnlbl.setFixedWidth(58)
        fn_row.addWidget(fnlbl)
        self.filename_edit = QLineEdit("recording.mp4")
        fn_row.addWidget(self.filename_edit, 1)
        root.addLayout(fn_row)

        root.addWidget(self._sep())

        # Timer
        self.timer_label = QLabel("00:00:00")
        self.timer_label.setObjectName("timer_label")
        self.timer_label.setFont(QFont("Courier", 18, QFont.Weight.Bold))
        self.timer_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        root.addWidget(self.timer_label)

        # Status + log button
        status_row = QHBoxLayout()
        self.status_label = QLabel("Ready")
        self.status_label.setObjectName("status_label")
        self.status_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        status_row.addWidget(self.status_label, 1)
        self.log_btn = QPushButton("view log")
        self.log_btn.setObjectName("log_btn")
        self.log_btn.setFixedWidth(62)
        self.log_btn.clicked.connect(self._show_log)
        status_row.addWidget(self.log_btn)
        root.addLayout(status_row)

        # Record / Stop
        self.record_btn = QPushButton("  RECORD")
        self.record_btn.setObjectName("record_btn")
        self.record_btn.clicked.connect(self._toggle)
        root.addWidget(self.record_btn)

    @staticmethod
    def _sep() -> QFrame:
        f = QFrame()
        f.setFrameShape(QFrame.Shape.HLine)
        return f

    # ------------------------------------------------------------------
    # Slots
    # ------------------------------------------------------------------

    def _choose_dir(self) -> None:
        d = QFileDialog.getExistingDirectory(self, "Select Output Directory", self._output_dir)
        if d:
            self._output_dir = d
            self.dir_label.setText(d)

    def _toggle(self) -> None:
        if self._worker is None:
            self._start_recording()
        else:
            self._stop_recording()

    def _start_recording(self) -> None:
        filename    = self._clean_filename()
        output_path = Path(self._output_dir) / filename

        if output_path.exists():
            reply = QMessageBox.question(
                self, "Overwrite?",
                f"'{filename}' already exists.\nOverwrite?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            )
            if reply != QMessageBox.StandardButton.Yes:
                return

        cmd = self._build_cmd(output_path)

        self._worker = RecordingWorker(cmd)
        self._worker.finished.connect(self._on_finished)
        self._worker.error.connect(self._on_error)
        self._worker.start()

        self._elapsed = 0
        self._tick_timer.start(1000)

        self.record_btn.setObjectName("stop_btn")
        self.record_btn.setText("  STOP")
        self.record_btn.setStyleSheet(DARK_STYLE)

        self.status_label.setText(f"Recording -> {filename}")
        self.monitor_combo.setEnabled(False)
        self.audio_combo.setEnabled(False)

    def _stop_recording(self) -> None:
        if self._worker:
            self._worker.stop()
            self._worker = None

        self._tick_timer.stop()

        self.record_btn.setObjectName("record_btn")
        self.record_btn.setText("  RECORD")
        self.record_btn.setStyleSheet(DARK_STYLE)

        self.timer_label.setText("00:00:00")
        self.status_label.setText("Ready")
        self._elapsed = 0
        self.monitor_combo.setEnabled(True)
        self.audio_combo.setEnabled(True)

    def _tick(self) -> None:
        self._elapsed += 1
        h =  self._elapsed // 3600
        m = (self._elapsed % 3600) // 60
        s =  self._elapsed % 60
        self.timer_label.setText(f"{h:02d}:{m:02d}:{s:02d}")

    def _on_finished(self) -> None:
        if self._worker is not None:
            self._stop_recording()

    def _on_error(self, msg: str) -> None:
        self._stop_recording()
        box = QMessageBox(self)
        box.setWindowTitle("Recording Failed")
        box.setIcon(QMessageBox.Icon.Critical)
        box.setText("ffmpeg exited early. Details:")
        box.setDetailedText(msg)
        box.exec()

    def _show_log(self) -> None:
        log_path = os.path.join(tempfile.gettempdir(), "screen_of_death_ffmpeg.log")
        try:
            with open(log_path, "r", encoding="utf-8", errors="replace") as f:
                content = f.read().strip()
        except FileNotFoundError:
            content = "(no log yet)"
        box = QMessageBox(self)
        box.setWindowTitle("ffmpeg log")
        box.setText("Last ffmpeg session:")
        box.setDetailedText(content or "(empty)")
        box.exec()

    def closeEvent(self, event) -> None:
        if self._worker:
            self._stop_recording()
        event.accept()

    # ------------------------------------------------------------------
    # ffmpeg command builder
    # ------------------------------------------------------------------

    def _clean_filename(self) -> str:
        name = self.filename_edit.text().strip() or "recording"
        if not name.lower().endswith(".mp4"):
            name += ".mp4"
        return name

    def _build_cmd(self, output_path: Path) -> list[str]:
        mon_idx   = self.monitor_combo.currentIndex()
        _, mon    = self._monitors[mon_idx]
        audio     = self.audio_combo.currentText()
        has_audio = audio != "No Audio"

        cmd = ["ffmpeg", "-y"]

        # --- Video input (gdigrab) ---
        if mon_idx == 0:
            cmd += ["-f", "gdigrab", "-framerate", "30", "-i", "desktop"]
        else:
            cmd += [
                "-f", "gdigrab",
                "-framerate", "30",
                "-offset_x",   str(mon["left"]),
                "-offset_y",   str(mon["top"]),
                "-video_size", f"{mon['width']}x{mon['height']}",
                "-i", "desktop",
            ]

        # --- Audio input (dshow) ---
        # -rtbufsize prevents dshow buffer overruns on slower machines
        if has_audio:
            cmd += [
                "-f", "dshow",
                "-rtbufsize", "256M",
                "-i", f"audio={audio}",
            ]

        # --- Explicit stream mapping ---
        # Without -map, ffmpeg can silently drop the audio stream
        # when mixing gdigrab + dshow inputs.
        if has_audio:
            cmd += ["-map", "0:v:0", "-map", "1:a:0"]

        # --- Video encoding ---
        cmd += [
            "-c:v", "libx264",
            "-crf", "23",
            "-preset", "ultrafast",
            "-pix_fmt", "yuv420p",
        ]

        # --- Audio encoding ---
        if has_audio:
            cmd += ["-c:a", "aac", "-b:a", "192k"]

        cmd.append(str(output_path))
        return cmd

# =============================================================================
# Entry Point
# =============================================================================

def main() -> None:
    app = QApplication(sys.argv)
    app.setStyleSheet(DARK_STYLE)

    splash = create_splash()
    if splash:
        splash.show()
        for msg in ["Initializing...", "Enumerating devices...", "Ready."]:
            splash.showMessage(
                "\n\n\n\n\n\n\n" + msg,
                Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignCenter,
                QColor(255, 255, 255),
            )
            app.processEvents()
            time.sleep(0.4)

    win = ScreenOfDeath()
    win.show()

    if splash:
        splash.finish(win)

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
